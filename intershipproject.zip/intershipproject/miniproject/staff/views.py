from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.models import User
from django.db.models import Q
from django.utils import timezone
from .forms import (
    BookingForm, BookingStatusForm, CustomerRegistrationForm,
    CustomerProfileForm, ServiceCenterRegistrationForm,
    ServiceCenterProfileForm
)
from .models import ServiceBooking, Customer, ServiceCenter


# ==================== Authentication Views ====================
def register_customer(request):
    """Register a new customer"""
    if request.method == 'POST':
        form = CustomerRegistrationForm(request.POST)
        if form.is_valid():
            user = User.objects.create_user(
                username=form.cleaned_data['username'],
                email=form.cleaned_data['email'],
                first_name=form.cleaned_data['first_name'],
                last_name=form.cleaned_data['last_name'],
                password=form.cleaned_data['password']
            )
            login(request, user)
            messages.success(request, "Customer account created successfully!")
            return redirect('customer_profile')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")
    else:
        form = CustomerRegistrationForm()
    return render(request, 'register_customer.html', {'form': form})


def register_service_center(request):
    """Register a new service center"""
    if request.method == 'POST':
        form = ServiceCenterRegistrationForm(request.POST)
        if form.is_valid():
            user = User.objects.create_user(
                username=form.cleaned_data['username'],
                email=form.cleaned_data['email'],
                first_name=form.cleaned_data['first_name'],
                last_name=form.cleaned_data['last_name'],
                password=form.cleaned_data['password']
            )
            user.is_staff = True
            user.save()
            login(request, user)
            messages.success(request, "Service center account created successfully!")
            return redirect('service_center_profile')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")
    else:
        form = ServiceCenterRegistrationForm()
    return render(request, 'register_service_center.html', {'form': form})


def login_view(request):
    """Login user"""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            if user.is_staff:
                return redirect('staff_dashboard')
            else:
                return redirect('customer_dashboard')
        else:
            messages.error(request, "Invalid username or password")
    return render(request, 'login.html')


def logout_view(request):
    """Logout user"""
    logout(request)
    messages.success(request, "Logged out successfully!")
    return redirect('home')


# ==================== Home & Index Views ====================
def home(request):
    """Home page"""
    return render(request, 'home.html')


def index(request):
    """Index page"""
    return render(request, 'index.html')


# ==================== Customer Views ====================
@login_required(login_url='login')
def customer_dashboard(request):
    """Customer dashboard - view bookings"""
    if not hasattr(request.user, 'customer'):
        return redirect('customer_profile')
    
    bookings = ServiceBooking.objects.filter(email=request.user.email)
    pending = bookings.filter(status='pending').count()
    accepted = bookings.filter(status='accepted').count()
    completed = bookings.filter(status='completed').count()
    
    context = {
        'bookings': bookings,
        'pending': pending,
        'accepted': accepted,
        'completed': completed,
    }
    return render(request, 'customer_dashboard.html', context)


@login_required(login_url='login')
def customer_profile(request):
    """Customer profile view/edit"""
    try:
        customer = Customer.objects.get(user=request.user)
    except Customer.DoesNotExist:
        customer = Customer.objects.create(user=request.user)
    
    if request.method == 'POST':
        form = CustomerProfileForm(request.POST, instance=customer)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated successfully!")
            return redirect('customer_dashboard')
    else:
        form = CustomerProfileForm(instance=customer)
    
    return render(request, 'customer_profile.html', {'form': form})


def book_service(request):
    """Book a service - public form"""
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save()
            messages.success(request, "Service booking request submitted successfully! We will contact you soon.")
            return redirect('booking_success', booking_id=booking.id)
    else:
        form = BookingForm()
    
    return render(request, 'booking_form.html', {'form': form})


def booking_success(request, booking_id):
    """Booking success page"""
    booking = get_object_or_404(ServiceBooking, id=booking_id)
    return render(request, 'booking_success.html', {'booking': booking})


@login_required(login_url='login')
def track_booking(request, booking_id):
    """Track individual booking status"""
    booking = get_object_or_404(ServiceBooking, id=booking_id)
    
    # Allow all users to view their booking (remove permission check)
    
    return render(request, 'track_booking.html', {'booking': booking})


# ==================== Staff Views ====================
@login_required(login_url='login')
def staff_dashboard(request):
    """Staff dashboard - manage bookings"""
    if not request.user.is_staff:
        messages.error(request, "Access denied. Staff only.")
        return redirect('home')
    
    bookings = ServiceBooking.objects.all()
    pending = bookings.filter(status='pending').count()
    accepted = bookings.filter(status='accepted').count()
    completed = bookings.filter(status='completed').count()
    rejected = bookings.filter(status='rejected').count()
    
    # Get filter from request
    status_filter = request.GET.get('status', 'all')
    if status_filter != 'all':
        bookings = bookings.filter(status=status_filter)
    
    context = {
        'bookings': bookings,
        'pending': pending,
        'accepted': accepted,
        'completed': completed,
        'rejected': rejected,
        'status_filter': status_filter,
    }
    return render(request, 'staff_dashboard.html', context)


@login_required(login_url='login')
def service_center_profile(request):
    """Service center profile view/edit"""
    if not request.user.is_staff:
        messages.error(request, "Access denied. Staff only.")
        return redirect('home')
    
    try:
        service_center = ServiceCenter.objects.get(user=request.user)
    except ServiceCenter.DoesNotExist:
        service_center = ServiceCenter.objects.create(user=request.user)
    
    if request.method == 'POST':
        form = ServiceCenterProfileForm(request.POST, instance=service_center)
        if form.is_valid():
            form.save()
            messages.success(request, "Service center profile updated successfully!")
            return redirect('staff_dashboard')
    else:
        form = ServiceCenterProfileForm(instance=service_center)
    
    return render(request, 'service_center_profile.html', {'form': form})


@login_required(login_url='login')
def manage_booking(request, booking_id):
    """Staff view to manage booking status"""
    if not request.user.is_staff:
        messages.error(request, "Access denied. Staff only.")
        return redirect('home')
    
    booking = get_object_or_404(ServiceBooking, id=booking_id)
    
    if request.method == 'POST':
        form = BookingStatusForm(request.POST, instance=booking)
        if form.is_valid():
            form.save()
            messages.success(request, "Booking updated successfully!")
            return redirect('staff_dashboard')
    else:
        form = BookingStatusForm(instance=booking)
    
    return render(request, 'manage_booking.html', {'booking': booking, 'form': form})


@login_required(login_url='login')
def accept_booking(request, booking_id):
    """Accept a booking"""
    if not request.user.is_staff:
        messages.error(request, "Access denied. Staff only.")
        return redirect('home')
    
    booking = get_object_or_404(ServiceBooking, id=booking_id)
    booking.status = 'accepted'
    booking.assigned_to = request.user
    booking.save()
    messages.success(request, "Booking accepted!")
    return redirect('staff_dashboard')


@login_required(login_url='login')
def reject_booking(request, booking_id):
    """Reject a booking"""
    if not request.user.is_staff:
        messages.error(request, "Access denied. Staff only.")
        return redirect('home')
    
    booking = get_object_or_404(ServiceBooking, id=booking_id)
    
    if request.method == 'POST':
        reason = request.POST.get('rejection_reason', '')
        booking.status = 'rejected'
        booking.rejection_reason = reason
        booking.save()
        messages.success(request, "Booking rejected!")
        return redirect('staff_dashboard')
    
    return render(request, 'reject_booking.html', {'booking': booking})


@login_required(login_url='login')
def complete_booking(request, booking_id):
    """Mark booking as completed"""
    if not request.user.is_staff:
        messages.error(request, "Access denied. Staff only.")
        return redirect('home')
    
    booking = get_object_or_404(ServiceBooking, id=booking_id)
    
    if request.method == 'POST':
        notes = request.POST.get('staff_notes', '')
        booking.status = 'completed'
        booking.staff_notes = notes
        booking.completed_at = timezone.now()
        booking.save()
        messages.success(request, "Booking marked as completed!")
        return redirect('staff_dashboard')
    
    return render(request, 'complete_booking.html', {'booking': booking})


# ==================== Admin Analytics ====================
@login_required(login_url='login')
def analytics_dashboard(request):
    """Analytics dashboard for admin/superuser"""
    if not request.user.is_superuser:
        messages.error(request, "Access denied. Admin only.")
        return redirect('home')
    
    total_bookings = ServiceBooking.objects.count()
    pending = ServiceBooking.objects.filter(status='pending').count()
    accepted = ServiceBooking.objects.filter(status='accepted').count()
    completed = ServiceBooking.objects.filter(status='completed').count()
    rejected = ServiceBooking.objects.filter(status='rejected').count()
    
    # Most common services
    from django.db.models import Count
    popular_services = ServiceBooking.objects.values('service_type').annotate(count=Count('id')).order_by('-count')[:5]
    
    # Recent bookings
    recent_bookings = ServiceBooking.objects.all()[:10]
    
    context = {
        'total_bookings': total_bookings,
        'pending': pending,
        'accepted': accepted,
        'completed': completed,
        'rejected': rejected,
        'popular_services': popular_services,
        'recent_bookings': recent_bookings,
    }
    return render(request, 'analytics_dashboard.html', context)