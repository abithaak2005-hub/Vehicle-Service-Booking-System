from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone


class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone = models.CharField(max_length=15)
    address = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.user.username} - {self.phone}"


class ServiceCenter(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    center_name = models.CharField(max_length=200)
    phone = models.CharField(max_length=15)
    address = models.TextField()
    opening_time = models.TimeField()
    closing_time = models.TimeField()
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.center_name


class ServiceBooking(models.Model):
    BOOKING_STATUS = [
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('completed', 'Completed'),
        ('rejected', 'Rejected'),
    ]
    
    SERVICE_TYPES = [
        ('regular', 'Regular Service'),
        ('brake_service', 'Brake Service'),
        ('engine_service', 'Engine Service'),
        ('tire_service', 'Tire Service'),
        ('general_repair', 'General Repair'),
        ('other', 'Other'),
    ]

    # Customer Information
    customer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='service_bookings', null=True, blank=True)
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    email = models.EmailField()

    # Vehicle Information
    vehicle_type = models.CharField(max_length=50)
    vehicle_model = models.CharField(max_length=100)
    vehicle_number = models.CharField(max_length=50, unique=True)

    # Service Information
    service_type = models.CharField(max_length=50, choices=SERVICE_TYPES, default='regular')
    service_date = models.DateField()
    service_time = models.TimeField(null=True, blank=True)
    notes = models.TextField(blank=True, null=True)

    # Status Tracking
    status = models.CharField(max_length=20, choices=BOOKING_STATUS, default='pending')
    assigned_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='assigned_bookings')
    
    # Timestamps
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(default=timezone.now)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    # Staff Notes
    staff_notes = models.TextField(blank=True, null=True)
    rejection_reason = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.name} - {self.vehicle_number} ({self.status})"

    class Meta:
        ordering = ['-created_at']


# Signal to send email notifications
@receiver(post_save, sender=ServiceBooking)
def send_booking_notification(sender, instance, created, **kwargs):
    if created:
        # Email to customer on booking creation
        subject = f"Service Booking Confirmation - {instance.vehicle_number}"
        message = f"""
Dear {instance.name},

Your service booking has been received. Here are the details:

Vehicle: {instance.vehicle_type} {instance.vehicle_model} ({instance.vehicle_number})
Service Type: {instance.get_service_type_display()}
Requested Date: {instance.service_date}
Status: {instance.get_status_display()}

We will notify you once the service center confirms your booking.

Best regards,
Vehicle Service Booking System
        """
        try:
            send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [instance.email])
        except Exception as e:
            print(f"Error sending email: {e}")
    else:
        # Email on status change
        if instance.status == 'accepted':
            subject = f"Your Service Booking Accepted - {instance.vehicle_number}"
            message = f"""
Dear {instance.name},

Your service booking has been accepted!

Vehicle: {instance.vehicle_type} {instance.vehicle_model} ({instance.vehicle_number})
Service Date: {instance.service_date}
Service Time: {instance.service_time}

Assigned Staff: {instance.assigned_to.first_name if instance.assigned_to else 'TBD'}

Please bring your vehicle on the scheduled date and time. If you have any questions, please contact us.

Best regards,
Vehicle Service Booking System
            """
            try:
                send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [instance.email])
            except Exception as e:
                print(f"Error sending email: {e}")
        
        elif instance.status == 'rejected':
            subject = f"Service Booking Declined - {instance.vehicle_number}"
            message = f"""
Dear {instance.name},

Unfortunately, your service booking request has been declined.

Reason: {instance.rejection_reason}

Please feel free to contact us to reschedule or for more information.

Best regards,
Vehicle Service Booking System
            """
            try:
                send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [instance.email])
            except Exception as e:
                print(f"Error sending email: {e}")
        
        elif instance.status == 'completed':
            subject = f"Your Service is Complete - {instance.vehicle_number}"
            message = f"""
Dear {instance.name},

Your vehicle service has been completed successfully!

Vehicle: {instance.vehicle_type} {instance.vehicle_model} ({instance.vehicle_number})
Completion Date: {instance.completed_at.date() if instance.completed_at else 'Today'}

Staff Notes: {instance.staff_notes}

Thank you for choosing our service center. We appreciate your business!

Best regards,
Vehicle Service Booking System
            """
            try:
                send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [instance.email])
            except Exception as e:
                print(f"Error sending email: {e}")