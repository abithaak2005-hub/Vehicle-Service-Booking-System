# Vehicle Service Booking System

A complete Django-based Vehicle Service Booking System with customer and staff dashboards, real-time status tracking, and email notifications.

## Features

### For Customers
- ✅ **Easy Booking**: Book service slots in just a few clicks
- ✅ **Real-Time Tracking**: Track booking status from Pending → Accepted → Completed
- ✅ **Email Notifications**: Get instant email updates on booking status changes
- ✅ **Customer Dashboard**: View all your bookings in one place
- ✅ **Profile Management**: Update your contact information and address

### For Service Centers
- ✅ **Booking Management**: View and manage all incoming service bookings
- ✅ **Accept/Reject Bookings**: Accept or reject customer requests with notes
- ✅ **Staff Dashboard**: Complete overview of all bookings with filtering
- ✅ **Status Updates**: Update booking progress and add service notes
- ✅ **Profile Management**: Manage service center details and operating hours

### For Administrators
- ✅ **Admin Panel**: Comprehensive Django admin interface with custom views
- ✅ **Analytics Dashboard**: View booking statistics and popular services
- ✅ **Bulk Actions**: Manage multiple bookings simultaneously
- ✅ **Advanced Filtering**: Filter bookings by status, date, and service type

## Project Structure

```
miniproject/
├── manage.py
├── db.sqlite3
├── miniproject/
│   ├── settings.py       # Project settings
│   ├── urls.py          # Main URL configuration
│   ├── wsgi.py
│   └── asgi.py
└── staff/
    ├── models.py        # Database models (Customer, ServiceCenter, ServiceBooking)
    ├── views.py         # All view functions
    ├── forms.py         # Django forms for booking and profile management
    ├── admin.py         # Admin panel configuration
    ├── apps.py
    ├── migrations/      # Database migrations
    └── templates/       # HTML templates
        ├── base.html
        ├── home.html
        ├── login.html
        ├── register_customer.html
        ├── register_service_center.html
        ├── booking_form.html
        ├── booking_success.html
        ├── customer_dashboard.html
        ├── customer_profile.html
        ├── staff_dashboard.html
        ├── service_center_profile.html
        ├── track_booking.html
        ├── manage_booking.html
        └── admin.html
```

## Installation & Setup

### 1. Clone or Setup Project
```bash
cd c:\Users\Abitha\Desktop\intershipproject\miniproject
```

### 2. Install Dependencies (if not already installed)
```bash
pip install django
```

### 3. Run Migrations
```bash
python manage.py migrate
```

### 4. Create Superuser (Admin Account)
```bash
python manage.py createsuperuser
# Follow prompts to create admin account
```

### 5. Start Development Server
```bash
python manage.py runserver
```

The application will be available at: **http://127.0.0.1:8000/**

## Usage Guide

### Customer Flow
1. **Register**: Click "Register" → "Customer" to create a customer account
2. **Book Service**: Navigate to "Book Service" and fill in vehicle and service details
3. **Track Status**: Log in to your dashboard to see all bookings and their status
4. **Email Updates**: Receive notifications when status changes

### Service Center Flow
1. **Register**: Click "Register" → "Service Center" to create a staff account
2. **View Dashboard**: Log in to see all pending bookings
3. **Manage Bookings**: Click "Manage" on any booking to:
   - Accept or reject the booking
   - Set service time
   - Assign to a staff member
   - Add service notes
4. **Complete Service**: Mark booking as completed with final notes

### Admin Flow
1. **Access Admin**: Navigate to `/admin/` and log in with superuser account
2. **View Analytics**: See dashboard with booking statistics
3. **Manage All Data**: View and edit customers, service centers, and bookings
4. **Bulk Actions**: Update multiple bookings at once

## Database Models

### ServiceBooking
- **Fields**: customer info, vehicle details, service type, dates/times, status, assigned staff, timestamps, notes
- **Status Options**: Pending, Accepted, Completed, Rejected
- **Auto-Updates**: Email notifications sent on status changes

### Customer
- **Fields**: user (link to User model), phone, address, created_at

### ServiceCenter
- **Fields**: user (link to User model), center name, phone, address, operating hours, created_at

## Email Configuration

The system uses Django's email backend. Currently configured for **console output** (development).

### For Production (Gmail Example):
Edit `miniproject/settings.py`:
```python
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'your-email@gmail.com'
EMAIL_HOST_PASSWORD = 'your-app-password'
```

## URL Routes

| Route | Purpose |
|-------|---------|
| `/` | Home page |
| `/login/` | User login |
| `/register/customer/` | Customer registration |
| `/register/service-center/` | Service center registration |
| `/book-service/` | Book a service |
| `/customer/dashboard/` | Customer dashboard |
| `/customer/profile/` | Customer profile |
| `/staff/dashboard/` | Staff dashboard |
| `/staff/profile/` | Service center profile |
| `/staff/booking/<id>/manage/` | Manage booking (staff) |
| `/booking/<id>/track/` | Track booking (customer) |
| `/admin/` | Django admin panel |

## Booking Status Flow

```
┌─────────────┐
│   Pending   │  (Customer submitted booking)
└──────┬──────┘
       │
       ├─► ┌──────────────┐
       │   │   Accepted   │  (Service center accepted)
       │   └──────┬───────┘
       │          │
       │          └─► ┌─────────────┐
       │              │ Completed   │  (Service finished)
       │              └─────────────┘
       │
       └─► ┌─────────────┐
           │  Rejected   │  (Service center rejected)
           └─────────────┘
```

## Testing the System

### Test Customer Booking:
1. Go to home page
2. Click "Book Service" or register as customer
3. Fill in booking form with vehicle details
4. Submit and view confirmation
5. Log in to customer dashboard to track

### Test Staff Management:
1. Register as service center (will have staff access)
2. Go to staff dashboard
3. See pending bookings
4. Click "Manage" to accept/reject
5. Set time, assign staff, add notes
6. Mark as completed

### Test Notifications:
- Check console output for email content (in development)
- Check Django admin to see all bookings

## Important Features

✅ **Status Tracking**: Real-time booking status updates
✅ **Email Notifications**: Automated emails on booking events
✅ **Role-Based Access**: Customers, staff, and admin have different permissions
✅ **Responsive Design**: Bootstrap 5 for mobile-friendly interface
✅ **Admin Dashboard**: Comprehensive booking management
✅ **Form Validation**: All forms have built-in validation
✅ **Database Relationships**: Proper foreign keys and constraints

## Future Enhancements

- SMS notifications
- Payment integration
- Service center ratings/reviews
- Advanced analytics and reporting
- Automated reminder emails
- Mobile app
- Multi-language support

## Troubleshooting

### Migrations Error
```bash
python manage.py migrate
```

### Create Admin Account
```bash
python manage.py createsuperuser
```

### Reset Database (Development Only)
```bash
# Delete db.sqlite3 and migrations
python manage.py migrate
python manage.py createsuperuser
```

## Support

For issues or questions, review the Django documentation:
- Django Documentation: https://docs.djangoproject.com/
- Django Models: https://docs.djangoproject.com/en/6.0/topics/db/models/
- Django Forms: https://docs.djangoproject.com/en/6.0/topics/forms/
- Django Admin: https://docs.djangoproject.com/en/6.0/ref/contrib/admin/

---

**System Status**: ✅ Fully Functional and Ready for Use
