#!/usr/bin/env python
"""
Quick Start Guide for Vehicle Service Booking System
This file demonstrates how to test the system
"""

# ==================== SETUP INSTRUCTIONS ====================
"""
1. Navigate to project:
   cd c:\Users\Abitha\Desktop\intershipproject\miniproject

2. Run migrations:
   python manage.py migrate

3. Create admin account:
   python manage.py createsuperuser
   
4. Start server:
   python manage.py runserver

5. Open browser:
   http://127.0.0.1:8000/
"""

# ==================== TEST SCENARIOS ====================

# TEST 1: Customer Registration & Booking
"""
1. Go to home page (http://127.0.0.1:8000/)
2. Click "Register" → "Customer"
3. Fill in:
   - Username: john_doe
   - Email: john@example.com
   - First Name: John
   - Last Name: Doe
   - Password: TestPass123
4. After registration, you'll be redirected to profile page
5. Click "New Booking" or go to /book-service/
6. Fill in booking:
   - Name: John Doe
   - Phone: 9876543210
   - Email: john@example.com
   - Vehicle Type: Car
   - Vehicle Model: Honda Civic
   - Vehicle Number: KA-01-AB-1234
   - Service Type: Regular Service
   - Service Date: 2025-12-10
   - Service Time: 10:00 AM
   - Notes: Regular maintenance check
7. Submit and verify success page
8. You can now track booking from dashboard
"""

# TEST 2: Service Center Registration & Management
"""
1. Go to home page
2. Click "Register" → "Service Center"
3. Fill in:
   - Username: service_center_1
   - Email: center@example.com
   - First Name: ABC
   - Last Name: Service Center
   - Password: TestPass123
4. After registration, fill in service center profile:
   - Center Name: ABC Auto Service
   - Phone: 9876543210
   - Address: 123 Service Lane, City
   - Opening Time: 08:00
   - Closing Time: 18:00
5. You'll see Staff Dashboard with pending bookings
6. Click "Manage" on a booking to:
   - Change status to "Accepted"
   - Set service time: 10:00 AM
   - Assign to staff
   - Add service notes
7. Customer receives email notification
8. Later, mark booking as "Completed" with final notes
"""

# TEST 3: Admin Panel Access
"""
1. Go to http://127.0.0.1:8000/admin/
2. Log in with your superuser account
3. View and manage:
   - Customers
   - Service Centers
   - Service Bookings
4. Use bulk actions to:
   - Mark multiple bookings as accepted
   - Mark multiple as completed
5. Use filters to find specific bookings
"""

# TEST 4: Email Notifications
"""
In development mode, emails are printed to console.
Watch the terminal output when:
1. Customer submits booking
2. Staff accepts booking
3. Staff rejects booking
4. Staff marks booking as completed

Each event triggers an email which appears in terminal.

For production, configure SMTP in settings.py
"""

# ==================== KEY URLS ====================
"""
Home: http://127.0.0.1:8000/
Login: http://127.0.0.1:8000/login/
Register Customer: http://127.0.0.1:8000/register/customer/
Register Service Center: http://127.0.0.1:8000/register/service-center/
Book Service: http://127.0.0.1:8000/book-service/
Customer Dashboard: http://127.0.0.1:8000/customer/dashboard/
Staff Dashboard: http://127.0.0.1:8000/staff/dashboard/
Admin: http://127.0.0.1:8000/admin/
"""

# ==================== FEATURES TO TEST ====================
"""
✅ User Registration (Customer & Service Center)
✅ User Login/Logout
✅ Service Booking Submission
✅ Email Notifications (check console)
✅ Booking Status Tracking
✅ Dashboard Statistics
✅ Staff Booking Management
✅ Accept/Reject Bookings
✅ Mark Bookings as Completed
✅ Admin Panel Access
✅ Bulk Actions in Admin
✅ Role-Based Access Control
✅ Form Validation
"""

# ==================== USEFUL COMMANDS ====================
"""
# Run migrations
python manage.py migrate

# Create superuser (admin)
python manage.py createsuperuser

# Start server
python manage.py runserver

# Start server on specific port
python manage.py runserver 8001

# Make migrations for model changes
python manage.py makemigrations

# Check for issues
python manage.py check

# Django shell (test code)
python manage.py shell

# See all database tables
python manage.py dbshell

# Export data
python manage.py dumpdata > data.json

# Import data
python manage.py loaddata data.json

# Clear all data
python manage.py flush
"""

# ==================== DATABASE INFO ====================
"""
Database: SQLite (db.sqlite3)

Tables:
- auth_user (Django built-in)
- staff_customer
- staff_servicecenter
- staff_servicebooking

To view database:
- Use DB Browser for SQLite
- Or use: python manage.py dbshell
"""

# ==================== PRODUCTION CHECKLIST ====================
"""
Before deploying to production:

☐ Set DEBUG = False in settings.py
☐ Configure SECRET_KEY (use environment variables)
☐ Set ALLOWED_HOSTS
☐ Configure email backend (SMTP)
☐ Set up static files collection
☐ Configure database (PostgreSQL recommended)
☐ Set up HTTPS/SSL certificate
☐ Configure CORS if needed
☐ Set up logging
☐ Run security checks: python manage.py check --deploy
☐ Use gunicorn or uWSGI for production server
☐ Set up Nginx/Apache reverse proxy
"""
