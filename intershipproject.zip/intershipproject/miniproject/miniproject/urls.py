"""
URL configuration for miniproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from staff import views

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # Home pages
    path('', views.home, name='home'),
    path('index/', views.index, name='index'),
    
    # Authentication
    path('register/customer/', views.register_customer, name='register_customer'),
    path('register/service-center/', views.register_service_center, name='register_service_center'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    
    # Booking
    path('book-service/', views.book_service, name='book_service'),
    path('booking/<int:booking_id>/success/', views.booking_success, name='booking_success'),
    path('booking/<int:booking_id>/track/', views.track_booking, name='track_booking'),
    
    # Customer Dashboard
    path('customer/dashboard/', views.customer_dashboard, name='customer_dashboard'),
    path('customer/profile/', views.customer_profile, name='customer_profile'),
    
    # Staff Dashboard
    path('staff/dashboard/', views.staff_dashboard, name='staff_dashboard'),
    path('staff/profile/', views.service_center_profile, name='service_center_profile'),
    path('staff/booking/<int:booking_id>/manage/', views.manage_booking, name='manage_booking'),
    path('staff/booking/<int:booking_id>/accept/', views.accept_booking, name='accept_booking'),
    path('staff/booking/<int:booking_id>/reject/', views.reject_booking, name='reject_booking'),
    path('staff/booking/<int:booking_id>/complete/', views.complete_booking, name='complete_booking'),
    
    # Admin Analytics
    path('admin/analytics/', views.analytics_dashboard, name='analytics_dashboard'),
]
